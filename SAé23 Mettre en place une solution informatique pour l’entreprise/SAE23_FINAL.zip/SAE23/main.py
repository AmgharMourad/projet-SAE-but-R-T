# coding: utf-8
import json
from flask import Flask, render_template, request, url_for, redirect
import requests
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
import datetime
from apscheduler.schedulers.background import BackgroundScheduler


def conditions_meteo(code):
    wmo_mapping = {
    "0": "Ciel clair",
    "1": "Quelques nuages",
    "2": "Nuages dispersés",
    "3": "Nuages fragmentés",
    "4": "Ciel couvert",
    "5": "Brouillard",
    "61": "Pluie faible",
    "63": "Pluie modérée",
    "65": "Pluie forte",
    "80": "Averses de pluie",
    "95": "Orages isolés",
    "71": "Neige faible",
    "73": "Neige modérée",
    "75": "Neige forte",
    "85": "Averses de neige",
    "66": "Neige fondue",
    "86": "Averses de neige fondue",
    "64": "Pluie verglaçante",
    "93": "Grêle",
    "90": "Averses de grêle",}

    return wmo_mapping[code]



app = Flask(__name__,static_folder='static',template_folder='templates',
            static_url_path='')
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///etudiants.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
db = SQLAlchemy(app)


def clean_json(file):
    f=open(file,"r")
    data=f.read()
    f.close()
    data=json.loads(data)
    
    for student in data:
        if student["ville 2"]=="//":
            del student["ville 2"]
            del student["adresse 2"]

    
    f=open(file,"w")
    f.write(json.dumps(data))
    f.close()

def get_json(file):
    f=open(file,"r")
    data=f.read()
    f.close()
    data=json.loads(data)
    return data



class Etudiant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom_prenom = db.Column(db.String(200), nullable=False)
    complement_adresse1 = db.Column(db.String(200), nullable=True)
    complement_adresse2 = db.Column(db.String(200), nullable=True)
    id_lieu1 = db.Column(db.Integer, db.ForeignKey('lieu.id'), nullable=False)
    id_lieu2 = db.Column(db.Integer, db.ForeignKey('lieu.id'), nullable=True)
    groupe = db.Column(db.String(100), nullable=False)

    def __repr__(self):
        return self.nom_prenom

class Lieu(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom_ville = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return f"{self.nom_ville} "

class Temperature(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    id_lieu = db.Column(db.Integer, db.ForeignKey('lieu.id'), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.datetime.utcnow)

    def __repr__(self):
        return f"{self.temperature}°C -  {self.date}"

# (Les autres fonctions restent inchangées, sauf update_temperature_history() et fill_db())

def update_temperature_history():
    with app.app_context():
        etudiants = Etudiant.query.all()
        for etudiant in etudiants:
            for lieu in [etudiant.lieu1, etudiant.lieu2]:
                if lieu is not None:
                    meteo = get_meteo(lieu.nom_ville)
                    if isinstance(meteo, dict):
                        temperature = meteo['temperature']
                        temp_record = Temperature(id_lieu=lieu.id, temperature=temperature)
                        db.session.add(temp_record)
                    else:
                        print("Erreur dans l'adresse")
        db.session.commit()

def ajouter_lieu(nom_ville):
    with app.app_context():
        lieu = Lieu(nom_ville=nom_ville)
        db.session.add(lieu)
        db.session.commit()
        return lieu.id


def ajouter_etudiant(nom_prenom, complement_adresse1, complement_adresse2, id_lieu1, id_lieu2, groupe):
    with app.app_context():
        etudiant = Etudiant(nom_prenom=nom_prenom, complement_adresse1=complement_adresse1, complement_adresse2=complement_adresse2, id_lieu1=id_lieu1, id_lieu2=id_lieu2, groupe=groupe)
        db.session.add(etudiant)
        db.session.commit()


def fill_db():
    etudiants = get_json("data/etudiants.json")
    lieux = set()
    for etudiant in etudiants:
        lieux.add((etudiant["ville 1"]))
        if "ville 2" in etudiant:
            lieux.add((etudiant["ville 2"]))

    lieu_ids = {}
    for lieu in lieux:
        nom_ville = lieu
        lieu_id = ajouter_lieu(nom_ville)
        lieu_ids[lieu] = lieu_id

    for etudiant in etudiants:
        nom_prenom = etudiant["Nom"] + " " + etudiant["Prenom"]
        complement_adresse1 = etudiant["adresse 1"]
        id_lieu1 = lieu_ids[(etudiant["ville 1"])]
        if "adresse 2" in etudiant:
            complement_adresse2 = etudiant["adresse 2"]
            id_lieu2 = lieu_ids[(etudiant["ville 2"])]
        else:
            complement_adresse2 = None
            id_lieu2 = None
        groupe = input(f"De quel groupe fait partie {nom_prenom} ? : ")
        ajouter_etudiant(nom_prenom, complement_adresse1, complement_adresse2, id_lieu1, id_lieu2, groupe)




def get_meteo(adresse):
    # Géocodage de l'adresse en utilisant l'API Nominatim d'OpenStreetMap
    print(adresse)
    geo_url = "https://nominatim.openstreetmap.org/search"
    geo_params = {"q": adresse, "format": "json"}
    geo_response = requests.get(geo_url, params=geo_params)

    if geo_response.status_code != 200:
        return "Impossible d'obtenir les coordonnées géographiques de l'adresse."

    geo_data = geo_response.json()
    if not geo_data:
        return "Adresse introuvable."

    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    # Obtention des prévisions météorologiques à l'aide de l'API Open-Meteo
    meteo_url = "https://api.open-meteo.com/v1/forecast"
    meteo_params = {
        "latitude": lat,
        "longitude": lon,
        "current_weather": "true",
    }
    meteo_response = requests.get(meteo_url, params=meteo_params)

    if meteo_response.status_code != 200:
        print(meteo_response.text)
        return "Impossible d'obtenir les prévisions météorologiques."+meteo_response.text

    meteo_data = meteo_response.json()
    if not meteo_data or "current_weather" not in meteo_data:
        return "Météo introuvable."

    current_weather = meteo_data["current_weather"]

    if "temperature" in current_weather and "weathercode" in current_weather:
        temperature = current_weather["temperature"]
        description = current_weather["weathercode"]
        return {
            "temperature": temperature,
            "description": conditions_meteo(str(description)),
            "lat": lat,
            "lon": lon,
        }
    else:
        return "Informations météorologiques incomplètes."





def get_lat_long(adresse):
    geo_url = "https://nominatim.openstreetmap.org/search"
    geo_params = {"q": adresse, "format": "json"}
    geo_response = requests.get(geo_url, params=geo_params)

    if geo_response.status_code != 200:
        return "Impossible d'obtenir les coordonnées géographiques de l'adresse."

    geo_data = geo_response.json()
    if not geo_data:
        return None

    lat = geo_data[0]["lat"]
    lon = geo_data[0]["lon"]

    return [lat,lon]    


scheduler = BackgroundScheduler()
scheduler.add_job(update_temperature_history, 'interval', hours=1)
scheduler.start()

"""
with app.app_context():
    db.create_all()

#clean_json("data/etudiants.json")
fill_db()
"""

@app.route("/", methods=["GET", "POST"])
def index():
    nom_prenom = request.args.get("name")
    etudiants = Etudiant.query.all()

    if nom_prenom is not None:
        etudiant = Etudiant.query.filter_by(nom_prenom=nom_prenom).first()

        if etudiant is not None:
            lieu1 = Lieu.query.get(etudiant.id_lieu1)
            lieu2 = Lieu.query.get(etudiant.id_lieu2) if etudiant.id_lieu2 else None
            print(f"[+] {lieu1}, {lieu2}")
            meteo1 = get_meteo(lieu1.nom_ville)
            print(meteo1)
            meteo2 = get_meteo(etudiant.complement_adresse2 + ", " + lieu2.nom_ville ) if lieu2 else None
            temperature_history1 = Temperature.query.filter_by(id_lieu=etudiant.id_lieu1).order_by(Temperature.date.desc()).all()
            temperature_history2 = Temperature.query.filter_by(id_lieu=etudiant.id_lieu2).order_by(Temperature.date.desc()).all() if etudiant.id_lieu2 else []

            return render_template("index.html", etudiants=etudiants, etudiant=etudiant, meteo1=meteo1, meteo2=meteo2, temperature_history1=temperature_history1, temperature_history2=temperature_history2,lieu1=lieu1,lieu2=lieu2)
        else:
            return render_template("index.html", etudiants=etudiants, error="Etudiant introuvable")

    return render_template("index.html", etudiants=etudiants)





if __name__ == "__main__":
    app.run(debug=True)


